#!/usr/bin/env python

from gendiff.cli import parsing_cli

def main():
    parsing_cli()




if __name__ == '__main__':
    main()
