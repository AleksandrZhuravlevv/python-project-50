### Hexlet tests and linter status:
[![Actions Status](https://github.com/AleksandrZhuravlevv/python-project-50/workflows/hexlet-check/badge.svg)](https://github.com/AleksandrZhuravlevv/python-project-50/actions)

<a href="https://asciinema.org/a/J5cwK0YzH31a6OQqstrsCOB8x" target="_blank"><img src="https://asciinema.org/a/J5cwK0YzH31a6OQqstrsCOB8x.svg" /></a>
