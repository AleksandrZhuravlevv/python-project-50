### Hexlet tests and linter status:
[![Actions Status](https://github.com/AleksandrZhuravlevv/python-project-50/workflows/hexlet-check/badge.svg)](https://github.com/AleksandrZhuravlevv/python-project-50/actions)

<a href="https://asciinema.org/a/J5cwK0YzH31a6OQqstrsCOB8x" target="_blank"><img src="https://asciinema.org/a/J5cwK0YzH31a6OQqstrsCOB8x.svg" /></a>

<a href="https://asciinema.org/a/TFc11utzkT5tJEvgRRR2pdbuY" target="_blank"><img src="https://asciinema.org/a/TFc11utzkT5tJEvgRRR2pdbuY.svg" /></a>

<a href="https://asciinema.org/a/BEvN0tt2tv5rN5q0psCB4BVGG" target="_blank"><img src="https://asciinema.org/a/BEvN0tt2tv5rN5q0psCB4BVGG.svg" /></a>
