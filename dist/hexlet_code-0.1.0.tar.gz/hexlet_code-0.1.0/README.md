### Hexlet tests and linter status:
[![Actions Status](https://github.com/AleksandrZhuravlevv/python-project-50/workflows/hexlet-check/badge.svg)](https://github.com/AleksandrZhuravlevv/python-project-50/actions)

<a href="https://asciinema.org/a/ItcOwTdu3liDjzEsU5Ya6uUZO" target="_blank"><img src="https://asciinema.org/a/ItcOwTdu3liDjzEsU5Ya6uUZO.svg" /></a>
