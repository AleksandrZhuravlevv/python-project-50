import json


def json_f(text):
    return json.dumps(text, indent=4)
