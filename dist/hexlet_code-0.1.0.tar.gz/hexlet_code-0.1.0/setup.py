# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['gendiff', 'gendiff.formatters', 'gendiff.scripts']

package_data = \
{'': ['*']}

install_requires = \
['argparse>=1.4.0,<2.0.0',
 'prompt>=0.4.1,<0.5.0',
 'pytest-cov>=4.0.0,<5.0.0',
 'pyyaml>=6.0,<7.0']

entry_points = \
{'console_scripts': ['gendiff = gendiff.scripts.gendiff:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/AleksandrZhuravlevv/python-project-50/workflows/hexlet-check/badge.svg)](https://github.com/AleksandrZhuravlevv/python-project-50/actions)\n\n<a href="https://asciinema.org/a/J5cwK0YzH31a6OQqstrsCOB8x" target="_blank"><img src="https://asciinema.org/a/J5cwK0YzH31a6OQqstrsCOB8x.svg" /></a>\n\n<a href="https://asciinema.org/a/TFc11utzkT5tJEvgRRR2pdbuY" target="_blank"><img src="https://asciinema.org/a/TFc11utzkT5tJEvgRRR2pdbuY.svg" /></a>\n\n<a href="https://asciinema.org/a/BEvN0tt2tv5rN5q0psCB4BVGG" target="_blank"><img src="https://asciinema.org/a/BEvN0tt2tv5rN5q0psCB4BVGG.svg" /></a>\n\n<a href="https://asciinema.org/a/ykwL5BbQEvvSgwh8cP05mEjbl" target="_blank"><img src="https://asciinema.org/a/ykwL5BbQEvvSgwh8cP05mEjbl.svg" /></a>\n',
    'author': 'Aleksandr Zhuravlev',
    'author_email': 'Alexandrzhuravlyov828@yandex.ru',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
